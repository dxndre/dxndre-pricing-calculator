<?php

use Dompdf\Dompdf;
use Dompdf\Options;

// Register Activation Hook

require_once DX_PC_PATH . 'inc/install.php';

register_activation_hook(__FILE__, 'dx_pricing_create_tables');

// Finalising a quote

add_action('wp_ajax_dx_finalize_quote', 'dx_finalize_quote');
add_action('wp_ajax_nopriv_dx_finalize_quote', 'dx_finalize_quote');

function dx_finalize_quote() {

	if (empty($_POST['state'])) {
		wp_send_json_error(['message' => 'Missing state']);
	}

	$state = json_decode(stripslashes($_POST['state']), true);

	if (!$state || !is_array($state)) {
		wp_send_json_error(['message' => 'Invalid data']);
	}

	$state = dx_validate_estimate_state($state);
	if (is_wp_error($state)) wp_send_json_error(['message'=>$state->get_error_message()]);
	$reference = sanitize_text_field($_POST['estimate_reference'] ?? '');
	$token = sanitize_text_field($_POST['estimate_token'] ?? '');
	if ($reference) {
		$stored = get_transient('dx_estimate_edit_' . $reference);
		if (!$stored || !$token || !hash_equals($stored, $token) || !dx_get_quote_by_invoice($reference)) wp_send_json_error(['message'=>'This estimate can no longer be edited. Please start a new estimate.']);
		$invoice = $reference;
		$state['estimate_reference'] = $invoice;
		global $wpdb;
		$saved = $wpdb->update($wpdb->prefix.'dx_quotes', ['state'=>wp_json_encode($state),'total'=>$state['total']], ['invoice'=>$invoice], ['%s','%f'], ['%s']);
	} else {
		$invoice = dx_get_next_invoice_number();
		$token = wp_generate_password(40, false, false);
		$state['estimate_reference'] = $invoice;
		$saved = dx_save_quote($invoice, $state, $state['total']);
		set_transient('dx_estimate_edit_' . $invoice, $token, 30 * DAY_IN_SECONDS);
	}
	if ($saved === false) wp_send_json_error(['message'=>'The estimate could not be saved. Please try again.']);
	wp_send_json_success(['invoice'=>$invoice, 'token'=>$token, 'url'=>home_url("/proposal/$invoice/")]);
}

/* ==========================================================
   DOMPDF FACTORY
========================================================== */

function dx_create_dompdf() {

	$options = new Options();
	$options->set('isRemoteEnabled', true);
	$options->set('isHtml5ParserEnabled', true);
	$options->set('defaultFont', 'Outfit');

	// Keep generated font metrics in a writable cache, separate from bundled fonts.
	$font_cache = WP_CONTENT_DIR . '/uploads/dompdf-font-cache';
	wp_mkdir_p($font_cache);
	$options->set('fontDir', $font_cache);
	$options->set('fontCache', $font_cache);
	$options->set('chroot', [WP_CONTENT_DIR, DX_PC_PATH]);

	return new Dompdf($options);
}

/* ==========================================================
   SEND QUOTE (EMAIL PROPOSAL)
========================================================== */

add_action('wp_ajax_dx_send_quote', 'dx_send_quote');
add_action('wp_ajax_nopriv_dx_send_quote', 'dx_send_quote');

function dx_send_quote() {

	if (empty($_POST['state'])) {
		wp_send_json_error(['message' => 'Missing state']);
	}

	$state = json_decode(stripslashes($_POST['state']), true);

	if (!$state || !is_array($state)) {
		wp_send_json_error(['message' => 'Invalid data']);
	}

	$state = dx_validate_estimate_state($state);
	if (is_wp_error($state)) wp_die(esc_html($state->get_error_message()));

	if (!class_exists(Dompdf::class)) {
		wp_send_json_error(['message' => 'PDF engine unavailable']);
	}

	// Build HTML
	$html = dx_build_quote_html($state);

	// Create Dompdf
	$dompdf = dx_create_dompdf();
	$dompdf->loadHtml($html, 'UTF-8');
	$dompdf->setPaper('A4', 'portrait');
	$dompdf->render();

	$pdf_output = $dompdf->output();

	// Save temporary file
	$upload_dir = wp_upload_dir();
	$filename   = 'project-proposal-' . time() . '.pdf';
	$file_path  = trailingslashit($upload_dir['path']) . $filename;

	file_put_contents($file_path, $pdf_output);

	// Email recipient
	$to = sanitize_email(
		$state['contact']['email'] ?? get_option('admin_email')
	);

	// Send email
	$sent = wp_mail(
		$to,
		'Your Project Proposal',
		'
		<p>Hi,</p>
		<p>Attached is your personalised project proposal.</p>
		<p>If you’d like to discuss next steps, simply reply to this email.</p>
		<p>— D’André</p>
		',
		['Content-Type: text/html; charset=UTF-8'],
		[$file_path]
	);

	// Cleanup temp file
	if (file_exists($file_path)) {
		unlink($file_path);
	}

	if (!$sent) {
		wp_send_json_error(['message' => 'Email failed']);
	}

	// Optional lead logging
	if (function_exists('dx_log_lead')) {
		dx_log_lead($to, 'pricing-calculator');
	}

	wp_send_json_success();
}

/* ==========================================================
   DOWNLOAD PDF (NO EMAIL)
========================================================== */

add_action('wp_ajax_dx_generate_quote_pdf', 'dx_generate_quote_pdf');
add_action('wp_ajax_nopriv_dx_generate_quote_pdf', 'dx_generate_quote_pdf');

function dx_generate_quote_pdf() {

	if (empty($_POST['state'])) {
		wp_die('Missing data');
	}

	$state = json_decode(stripslashes($_POST['state']), true);

	if (!$state || !is_array($state)) {
		wp_die('Invalid data');
	}

	$state = dx_validate_estimate_state($state);
	if (is_wp_error($state)) wp_die(esc_html($state->get_error_message()));

	if (!class_exists(Dompdf::class)) {
		wp_die('PDF engine unavailable');
	}

	$html = dx_build_quote_html($state);

	$dompdf = dx_create_dompdf();
	$dompdf->loadHtml($html, 'UTF-8');
	$dompdf->setPaper('A4', 'portrait');
	$dompdf->render();

	header('Content-Type: application/pdf');
	header('Content-Disposition: attachment; filename="project-proposal.pdf"');
	header('Cache-Control: private, max-age=0, must-revalidate');
	header('Pragma: public');

	echo $dompdf->output();
	exit;
}

/* ==========================================================
   LEAD LOGGING (OPTIONAL)
========================================================== */

function dx_log_lead($email, $source) {
	global $wpdb;

	$wpdb->insert(
		$wpdb->prefix . 'dx_pricing_leads',
		[
			'email'      => sanitize_email($email),
			'source'     => sanitize_text_field($source),
			'created_at' => current_time('mysql'),
		]
	);
}

// Email Quote

add_action('wp_ajax_dx_email_quote_pdf', 'dx_email_quote_pdf');
add_action('wp_ajax_nopriv_dx_email_quote_pdf', 'dx_email_quote_pdf');

function dx_email_quote_pdf() {

	$name    = sanitize_text_field($_POST['name'] ?? '');
	$email   = sanitize_email($_POST['email'] ?? '');
	$invoice = sanitize_text_field($_POST['invoice'] ?? '');

	if (!$name || !$email || !$invoice) {
		wp_send_json_error();
	}

	$quote = dx_get_quote_by_invoice(basename($invoice));

	if (!$quote) {
		wp_send_json_error();
	}

	$state = json_decode($quote->state, true);

	// Generate PDF
	$html   = dx_build_quote_html($state);
	$dompdf = dx_create_dompdf();
	$dompdf->loadHtml($html);
	$dompdf->render();

	$pdf = $dompdf->output();

	$tmp = wp_tempnam($invoice . '.pdf');
	file_put_contents($tmp, $pdf);

	$headers = [
		'Content-Type: text/html; charset=UTF-8',
		'From: DXNDRE <hello@dxndre.co.uk>',
	];

	$message = "
		<p>Hi {$name},</p>

		<p>
			Thank you for taking the time to build your quote — I’ve attached a copy of your proposal for reference.
		</p>

		<p>
			If you have any questions or would like to talk through next steps, just reply to this email.
		</p>

		<p>
			Best,<br>
			D’André
		</p>
	";

	wp_mail(
		$email,
		'Your Project Proposal',
		$message,
		$headers,
		[$tmp]
	);

	@unlink($tmp);

	wp_send_json_success();
}