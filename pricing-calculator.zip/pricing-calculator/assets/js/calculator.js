(() => {

	/* ==========================
	   STATE + PRICING
	========================== */

	const state = {
		service: null,
		scope: null,
		type: null,
		features: [],
		timeline: null,
		extras: [],
		client_name: '',
		client_company: '',
		retainer_level: null,
		retainer_areas: [],
		retainer_turnaround: null,
		retainer_commitment: null,
		retainer_addons: [],
		contact: {},
		total: 0,
	};

	const prices = DX_PRICING?.prices || {};

	const priceMaps = {
		services: prices.services || {},
		scope: prices.scope || {},
		type: prices.type || {},
		features: prices.features || {},
		timeline: prices.timeline || {},
		extras: prices.extras || {},
		retainer_level: prices.retainer_level || prices.retainer_levels || {},
		retainer_areas: prices.retainer_areas || {},
		retainer_turnaround: prices.retainer_turnaround || {},
		retainer_commitment: prices.retainer_commitment || {},
		retainer_addons: prices.retainer_addons || {},
	};

	/* ==========================
	   DOM REFERENCES
	========================== */

	const calculator = document.querySelector('.pricing-calculator');
	if (!calculator) return;

	const steps = [...calculator.querySelectorAll('.calculator-step')];
	const stepsContainer = calculator.querySelector('.steps-container');
	const breakdownEls = calculator.querySelectorAll('.summary-breakdown');
	const totalEls = calculator.querySelectorAll('.price');
	const nextBtn = calculator.querySelector('.next-step');
	const prevBtn = calculator.querySelector('.prev-step');
	const emailModal = document.getElementById('email-quote-modal');
	const progressFill = calculator.querySelector('.progress-fill');
	const progressLabel = calculator.querySelector('.progress-label');
	const successEl = calculator.querySelector('.calculator-success');
	const summaryTitleEl = calculator.querySelector('[data-summary-title]');
	const summaryIntroEl = calculator.querySelector('[data-summary-intro]');

	if (!steps.length || !stepsContainer || !nextBtn || !prevBtn) return;

	const stepLookup = steps.reduce((acc, step) => {
		const key = step.getAttribute('data-step');
		if (key) {
			acc[key] = step;
		}
		return acc;
	}, {});

	const flows = {
		default: ['1', '2', '3', '4', '5', '6', '7'],
		design: ['1', '2', '3', '5', '7'],
		landing_page: ['1', '3', '5', '7'],
		development: ['1', '2', '3', '4', '5', '6', '7'],
		wp_development: ['1', '2', '3', '4', '5', '6', '7'],
		comprehensive: ['1', '2', '3', '4', '5', '6', '7'],
		retainer: ['1', 'retainer_level', 'retainer_areas', 'retainer_turnaround', 'retainer_commitment', 'retainer_addons', '7'],
	};

	const summaryFlowSteps = {
		default: [
			{ key: 'service', type: 'radio', group: 'service', prices: priceMaps.services },
			{ key: 'scope', type: 'radio', group: 'scope', prices: priceMaps.scope },
			{ key: 'type', type: 'radio', group: 'type', prices: priceMaps.type },
			{ key: 'features', type: 'checkbox', group: 'features', prices: priceMaps.features },
			{ key: 'timeline', type: 'radio', group: 'timeline', prices: priceMaps.timeline },
			{ key: 'extras', type: 'checkbox', group: 'extras', prices: priceMaps.extras },
		],
		design: [
			{ key: 'service', type: 'radio', group: 'service', prices: priceMaps.services },
			{ key: 'scope', type: 'radio', group: 'scope', prices: priceMaps.scope },
			{ key: 'type', type: 'radio', group: 'type', prices: priceMaps.type },
			{ key: 'timeline', type: 'radio', group: 'timeline', prices: priceMaps.timeline },
		],
		landing_page: [
			{ key: 'service', type: 'radio', group: 'service', prices: priceMaps.services },
			{ key: 'type', type: 'radio', group: 'type', prices: priceMaps.type },
			{ key: 'timeline', type: 'radio', group: 'timeline', prices: priceMaps.timeline },
		],
		retainer: [
			{ key: 'service', type: 'radio', group: 'service', prices: priceMaps.services },
			{ key: 'retainer_level', type: 'radio', group: 'retainer_level', prices: priceMaps.retainer_level },
			{ key: 'retainer_areas', type: 'checkbox', group: 'retainer_areas', prices: priceMaps.retainer_areas },
			{ key: 'retainer_turnaround', type: 'radio', group: 'retainer_turnaround', prices: priceMaps.retainer_turnaround },
			{ key: 'retainer_commitment', type: 'radio', group: 'retainer_commitment', prices: priceMaps.retainer_commitment },
			{ key: 'retainer_addons', type: 'checkbox', group: 'retainer_addons', prices: priceMaps.retainer_addons },
		],
	};

	let activeFlow = [...flows.default];
	let currentStepIndex = 0;
	let finalized = false;
	let invoiceUrl = '';
		let invoiceNumber = '';

	/* ==========================
	   UTILITIES
	========================== */

	const formatPrice = (value) => {
		const numeric = Number(value) || 0;
		const formatted = Math.abs(numeric).toLocaleString('en-GB', {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2,
		});

		return numeric < 0 ? `–£${formatted}` : `£${formatted}`;
	};

	const setButtonDisabled = (btn, disabled) => {
		if (!btn) return;
		btn.disabled = disabled;
		btn.classList.toggle('is-disabled', disabled);
	};

	const getCurrentStepKey = () => activeFlow[currentStepIndex];
	const getCurrentStepEl = () => stepLookup[getCurrentStepKey()] || null;
	const getFlowKey = () => {
		if (state.service === 'retainer') return 'retainer';
		if (state.service === 'design') return 'design';
		if (state.service === 'landing_page') return 'landing_page';
		return 'default';
	};

	const getActiveSummaryConfig = () => summaryFlowSteps[getFlowKey()] || summaryFlowSteps.default;

	const getFriendlyName = () => {
		const raw = (state.client_name || '').trim();
		if (!raw) return '';
		return raw.split(' ')[0];
	};

	const getSummaryHeading = () => {
		const name = getFriendlyName();
		return name ? `Here’s your summary, ${name}.` : 'Your project outline is ready.';
	};

	const getSummaryIntro = () => {
		const name = getFriendlyName();
		const company = (state.client_company || '').trim();

		if (state.service === 'retainer') {
			if (name && company) {
				return `This monthly partnership estimate has been shaped around the priorities you selected for ${company}, ${name}. It’s a refined starting point for ongoing support — with no pressure to proceed.`;
			}
			if (name) {
				return `This monthly partnership estimate has been shaped around the priorities you selected, ${name}. It’s a refined starting point for ongoing support — with no pressure to proceed.`;
			}
			return 'This monthly partnership estimate reflects the support level, priorities, and add-ons you selected. It’s a refined starting point for ongoing support — with no pressure to proceed.';
		}

		if (name && company) {
			return `This estimate reflects the scope, priorities, and level of craftsmanship selected for ${company}, ${name}. It’s a considered starting point — with no obligation and no pressure to proceed.`;
		}
		if (name) {
			return `This estimate reflects the scope, priorities, and level of craftsmanship you selected, ${name}. It’s a considered starting point — with no obligation and no pressure to proceed.`;
		}
		return 'This estimate reflects the scope, priorities, and level of craftsmanship you’ve selected. It’s a considered starting point — with no obligation and no pressure to proceed.';
	};

	const updateSummaryCopy = () => {
		if (summaryTitleEl) {
			summaryTitleEl.textContent = getSummaryHeading();
		}
		if (summaryIntroEl) {
			summaryIntroEl.textContent = getSummaryIntro();
		}
	};

	const getPriceForValue = (map, value) => {
		if (!map || value === null || value === undefined) return 0;
		const numeric = Number(map[value]);
		return Number.isFinite(numeric) ? numeric : 0;
	};

	const getLabelText = (group, value) => {
		const input = calculator.querySelector(`input[name="${group}"][value="${value}"]`);
		if (!input) return value;
		const label = input.closest('label');
		if (!label) return value;

		const cloned = label.cloneNode(true);
		cloned.querySelectorAll('input, .custom-radio, .custom-checkbox').forEach((el) => el.remove());
		return cloned.textContent.trim();
	};

	const fadeUpdatePrice = (el, value) => {
		if (!el) return;
		el.classList.add('is-updating');
		setTimeout(() => {
			el.textContent = formatPrice(value);
			requestAnimationFrame(() => {
				el.classList.remove('is-updating');
			});
		}, 150);
	};

	const isSummaryStep = (stepKey) => stepKey === '7';

	const applyActiveFlow = () => {
		activeFlow = [...(flows[getFlowKey()] || flows.default)];
		if (currentStepIndex >= activeFlow.length) {
			currentStepIndex = activeFlow.length - 1;
		}
	};

	const resetFinalizedQuote = () => {
		finalized = false;
		invoiceUrl = '';
		invoiceNumber = '';

		const summary = document.getElementById('invoice-summary');
		const input = document.getElementById('invoice-link');
		const meta = document.getElementById('invoice-meta');
		const viewBtn = document.getElementById('view-invoice');
		const copyBtn = calculator.querySelector('.copy-invoice');

		if (summary) summary.classList.add('is-hidden');
		if (input) input.value = '';
		if (meta) meta.textContent = '';
		if (viewBtn) {
			viewBtn.href = '#';
			viewBtn.classList.add('is-disabled');
		}
		if (copyBtn) {
			copyBtn.disabled = true;
		}
	};

	/* ==========================
	   PROGRESS + HEIGHT
	========================== */

	const updateProgress = () => {
		if (!progressFill || !progressLabel || !activeFlow.length) return;

		const current = currentStepIndex + 1;
		const total = activeFlow.length;
		const progress = total <= 1 ? 100 : Math.round((currentStepIndex / (total - 1)) * 100);

		progressFill.style.width = `${progress}%`;
		progressLabel.textContent = `Step ${current} of ${total}`;
	};

	const animateHeight = () => {
		if (!stepsContainer) return;
		const active = getCurrentStepEl();
		if (active) {
			stepsContainer.style.height = `${active.offsetHeight}px`;
		}
	};

	/* ==========================
	   SUMMARY UPDATE
	========================== */

	const updateSummary = () => {
		state.total = 0;
		const summaryConfig = getActiveSummaryConfig();

		summaryConfig.forEach((cfg) => {
			if (cfg.type === 'radio' && state[cfg.key]) {
				state.total += getPriceForValue(cfg.prices, state[cfg.key]);
			}

			if (cfg.type === 'checkbox' && Array.isArray(state[cfg.key]) && state[cfg.key].length) {
				state[cfg.key].forEach((value) => {
					state.total += getPriceForValue(cfg.prices, value);
				});
			}
		});

		breakdownEls.forEach((breakdownEl) => {
			breakdownEl.innerHTML = '';

			summaryConfig.forEach((cfg) => {
				if (cfg.type === 'radio' && state[cfg.key]) {
					const price = getPriceForValue(cfg.prices, state[cfg.key]);
					breakdownEl.insertAdjacentHTML(
						'beforeend',
						`<li class="${price < 0 ? 'is-discount' : ''}">
							<span class="summary-label">${getLabelText(cfg.group, state[cfg.key])}</span>
							<span class="summary-value">${formatPrice(price)}</span>
						</li>`
					);
				}

				if (cfg.type === 'checkbox' && Array.isArray(state[cfg.key]) && state[cfg.key].length) {
					state[cfg.key].forEach((value) => {
						const price = getPriceForValue(cfg.prices, value);
						breakdownEl.insertAdjacentHTML(
							'beforeend',
							`<li class="${price < 0 ? 'is-discount' : ''}">
								<span class="summary-label">${getLabelText(cfg.group, value)}</span>
								<span class="summary-value">${formatPrice(price)}</span>
							</li>`
						);
					});
				}
			});

			if (state.client_company) {
				breakdownEl.insertAdjacentHTML(
					'afterbegin',
					`<li>
						<span class="summary-label">Company</span>
						<span class="summary-value">${state.client_company}</span>
					</li>`
				);
			}
		});

		totalEls.forEach((el) => fadeUpdatePrice(el, state.total));
		updateSummaryCopy();
	};

	/* ==========================
	   STEP VALIDATION
	========================== */

	const validateStep = () => {
		const stepKey = getCurrentStepKey();
		if (!stepKey) return;

		if (isSummaryStep(stepKey)) {
			setButtonDisabled(nextBtn, false);
			return;
		}

		let valid = false;

		switch (stepKey) {
			case '1':
				valid = !!state.service;
				break;
			case '2':
				valid = !!state.scope;
				break;
			case '3':
				valid = !!state.type;
				break;
			case '4':
				valid = state.features.length > 0;
				break;
			case '5':
				valid = !!state.timeline;
				break;
			case '6':
				valid = true;
				break;
			case 'retainer_level':
				valid = !!state.retainer_level;
				break;
			case 'retainer_areas':
				valid = state.retainer_areas.length > 0;
				break;
			case 'retainer_turnaround':
				valid = !!state.retainer_turnaround;
				break;
			case 'retainer_commitment':
				valid = !!state.retainer_commitment;
				break;
			case 'retainer_addons':
				valid = true;
				break;
		}

		setButtonDisabled(nextBtn, !valid);
	};

	/* ==========================
	   STEP NAVIGATION
	========================== */

	const goToStepIndex = (index) => {
		if (index < 0 || index >= activeFlow.length) return;

		steps.forEach((step) => {
			step.classList.remove('is-active');
			step.hidden = true;
		});

		currentStepIndex = index;
		const target = getCurrentStepEl();
		if (!target) return;

		target.hidden = false;
		target.classList.add('is-active');

		setButtonDisabled(prevBtn, currentStepIndex === 0);
		prevBtn.classList.toggle('is-hidden', currentStepIndex === 0);

		if (currentStepIndex === activeFlow.length - 2) {
			nextBtn.textContent = 'Review summary';
		} else if (currentStepIndex === activeFlow.length - 1) {
			nextBtn.textContent = 'Finish';
		} else {
			nextBtn.textContent = 'Next';
		}

		updateProgress();
		validateStep();
		animateHeight();

		if (isSummaryStep(getCurrentStepKey())) {
			finalizeQuote();
		}
	};

	const refreshFlowFromService = () => {
		const previousKey = getCurrentStepKey();
		applyActiveFlow();
		const nextIndex = activeFlow.indexOf(previousKey);
		currentStepIndex = nextIndex >= 0 ? nextIndex : 0;
		goToStepIndex(currentStepIndex);
	};

	/* ==========================
	   FINALIZE QUOTE
	========================== */

	const finalizeQuote = async () => {
		if (finalized) return;

		const res = await fetch(DX_PRICING.ajax_url, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: new URLSearchParams({
				action: 'dx_finalize_quote',
				state: JSON.stringify(state),
			}),
		});

		const data = await res.json();

		if (!data.success) {
			alert(data.data?.message || 'Could not generate invoice. Please try again.');
			return;
		}

		finalized = true;
		invoiceNumber = data.data.invoice;
		invoiceUrl = data.data.url;

		const viewBtn = document.getElementById('view-invoice');
		if (viewBtn && invoiceUrl) {
			viewBtn.href = invoiceUrl;
			viewBtn.classList.remove('is-disabled');
		}

		const summary = document.getElementById('invoice-summary');
		const input = document.getElementById('invoice-link');
		const copyBtn = calculator.querySelector('.copy-invoice');
		const meta = document.getElementById('invoice-meta');

		if (summary) summary.classList.remove('is-hidden');
		if (input) input.value = invoiceUrl;
		if (meta) meta.textContent = `Invoice reference: ${invoiceNumber}`;
		if (copyBtn) copyBtn.disabled = false;
	};

	/* ==========================
	   FEATURE EXCLUSIVITY
	========================== */

	const syncFeatureExclusivity = () => {
		const noneInput = calculator.querySelector('input[name="features"][value="none"]');
		const featureInputs = [...calculator.querySelectorAll('input[name="features"]')].filter((input) => input.value !== 'none');

		if (!noneInput) return;

		if (noneInput.checked) {
			featureInputs.forEach((input) => {
				input.checked = false;
				input.disabled = true;
				input.closest('label')?.classList.remove('is-active');
			});
			state.features = ['none'];
		} else {
			featureInputs.forEach((input) => {
				input.disabled = false;
			});
			state.features = featureInputs.filter((input) => input.checked).map((input) => input.value);
		}

		syncActiveLabels();
		updateSummary();
		validateStep();
	};

	/* ==========================
	   INPUT BINDING
	========================== */

	const bindInputs = () => {
		calculator.querySelectorAll('input[name="service"]').forEach((input) => {
			input.addEventListener('change', () => {
				state.service = input.value;

				if (state.service === 'retainer') {
					state.scope = null;
					state.type = null;
					state.features = [];
					state.timeline = null;
					state.extras = [];
				} else {
					state.retainer_level = null;
					state.retainer_areas = [];
					state.retainer_turnaround = null;
					state.retainer_commitment = null;
					state.retainer_addons = [];
				}

				resetFinalizedQuote();
				updateSummary();
				refreshFlowFromService();
				syncActiveLabels();
				syncFeatureExclusivity();
			});
		});

		[
			{ name: 'scope', key: 'scope' },
			{ name: 'type', key: 'type' },
			{ name: 'timeline', key: 'timeline' },
			{ name: 'retainer_level', key: 'retainer_level' },
			{ name: 'retainer_turnaround', key: 'retainer_turnaround' },
			{ name: 'retainer_commitment', key: 'retainer_commitment' },
		].forEach((group) => {
			calculator.querySelectorAll(`input[name="${group.name}"]`).forEach((input) => {
				input.addEventListener('change', () => {
					state[group.key] = input.value;
					resetFinalizedQuote();
					updateSummary();
					validateStep();
					animateHeight();
					syncActiveLabels();
				});
			});
		});

		[
			{ name: 'extras', key: 'extras' },
			{ name: 'retainer_areas', key: 'retainer_areas' },
			{ name: 'retainer_addons', key: 'retainer_addons' },
		].forEach((group) => {
			calculator.querySelectorAll(`input[name="${group.name}"]`).forEach((input) => {
				input.addEventListener('change', () => {
					if (input.checked) {
						if (!state[group.key].includes(input.value)) {
							state[group.key].push(input.value);
						}
					} else {
						state[group.key] = state[group.key].filter((value) => value !== input.value);
					}

					resetFinalizedQuote();
					updateSummary();
					validateStep();
					animateHeight();
					syncActiveLabels();
				});
			});
		});

		calculator.querySelectorAll('input[name="features"]').forEach((input) => {
			input.addEventListener('change', () => {
				const noneInput = calculator.querySelector('input[name="features"][value="none"]');

				if (input.value === 'none' && input.checked) {
					state.features = ['none'];
				} else {
					state.features = state.features.filter((value) => value !== 'none');
					if (noneInput) noneInput.checked = false;

					if (input.checked) {
						if (!state.features.includes(input.value)) {
							state.features.push(input.value);
						}
					} else {
						state.features = state.features.filter((value) => value !== input.value);
					}
				}

				resetFinalizedQuote();
				syncFeatureExclusivity();
				animateHeight();
			});
		});

		const nameInput = calculator.querySelector('input[name="client_name"]');
		const companyInput = calculator.querySelector('input[name="client_company"]');

		nameInput?.addEventListener('input', () => {
			state.client_name = nameInput.value.trim();
			updateSummaryCopy();
		});

		companyInput?.addEventListener('input', () => {
			state.client_company = companyInput.value.trim();
			updateSummary();
		});
	};

	/* ==========================
	   NAV BUTTONS
	========================== */

		nextBtn.addEventListener('click', () => {
		if (currentStepIndex < activeFlow.length - 1) {
			goToStepIndex(currentStepIndex + 1);
			return;
		}

		fetch(DX_PRICING.ajax_url, {
			method: 'POST',
			body: new URLSearchParams({
				action: 'dx_finalize_quote',
				state: JSON.stringify(state),
			}),
		})
			.then((res) => res.json())
			.then((res) => {
				if (res.success) {
					window.location.href = res.data.url;
				}
			});
	});

	prevBtn.addEventListener('click', () => {
		if (currentStepIndex > 0) {
			goToStepIndex(currentStepIndex - 1);
		}
	});

	/* ==========================
	   ACTIVE LABEL SYNC
	========================== */

	const syncActiveLabels = () => {
		calculator.querySelectorAll('.options-group').forEach((group) => {
			group.querySelectorAll('input').forEach((input) => {
				const label = input.closest('label');
				if (!label) return;

				if (input.type === 'radio' && input.checked) {
					group.querySelectorAll('label').forEach((item) => item.classList.remove('is-active'));
					label.classList.add('is-active');
				}

				if (input.type === 'checkbox') {
					label.classList.toggle('is-active', input.checked);
					label.classList.toggle('is-disabled', input.disabled);
				}
			});
		});
	};

	/* ==========================
	   SCROLL LOGIC
	========================== */

	const initScrollableHint = () => {
		calculator.querySelectorAll('.options-group.long').forEach((group) => {
			const updateState = () => {
				const scrollTop = group.scrollTop;
				const scrollHeight = group.scrollHeight;
				const clientHeight = group.clientHeight;

				const isScrollable = scrollHeight > clientHeight + 1;
				const atTop = scrollTop <= 1;
				const atBottom = scrollTop + clientHeight >= scrollHeight - 1;

				group.classList.toggle('is-scrollable', isScrollable);
				group.classList.toggle('at-top', atTop);
				group.classList.toggle('at-bottom', atBottom);
				group.classList.toggle('is-middle', isScrollable && !atTop && !atBottom);
			};

			updateState();
			group.addEventListener('scroll', updateState);
		});
	};

	/* ==========================
	   TELEPORT MODAL TO <body>
	========================== */

		document.addEventListener('DOMContentLoaded', () => {
		const modal = document.getElementById('email-quote-modal');
		if (!modal) return;

		if (!modal.dataset.teleported) {
			document.body.appendChild(modal);
			modal.dataset.teleported = 'true';
		}
	});

	/* ==========================
	   DOWNLOAD GENERATED PDF
	========================== */

	calculator.querySelector('.download-pdf')?.addEventListener('click', () => {
		const form = document.createElement('form');
		form.method = 'POST';
		form.action = DX_PRICING.ajax_url;

		form.innerHTML = `
			<input type="hidden" name="action" value="dx_generate_quote_pdf">
			<input type="hidden" name="state" value='${JSON.stringify(state)}'>
		`;

		document.body.appendChild(form);
		form.submit();
		form.remove();
	});

	calculator.querySelector('.download-pdf')?.addEventListener('click', () => {
		if (typeof gtag === 'function') {
			gtag('event', 'download_proposal', {
				event_category: 'Proposal',
				event_label: state.total,
			});
		}
	});

	calculator.querySelector('.email-quote')?.addEventListener('click', () => {
		if (typeof gtag === 'function') {
			gtag('event', 'request_email_quote', {
				event_category: 'Proposal',
				event_label: state.total,
			});
		}
	});

	/* ==========================
	   COPY INVOICE LINK
	========================== */

	calculator.querySelector('.copy-invoice')?.addEventListener('click', (e) => {
		const btn = e.currentTarget;
		const input = document.getElementById('invoice-link');
		const icon = btn.querySelector('i');

		if (!input || !icon) return;

		const text = input.value;

		const showSuccess = () => {
			icon.classList.remove('fa-copy');
			icon.classList.add('fa-check');
			btn.disabled = true;

			setTimeout(() => {
				icon.classList.remove('fa-check');
				icon.classList.add('fa-copy');
				btn.disabled = false;
			}, 1800);
		};

		const showError = () => {
			icon.classList.remove('fa-copy');
			icon.classList.add('fa-xmark');

			setTimeout(() => {
				icon.classList.remove('fa-xmark');
				icon.classList.add('fa-copy');
			}, 1800);
		};

		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(text).then(showSuccess).catch(showError);
			return;
		}

		try {
			input.focus();
			input.select();
			document.execCommand('copy');
			showSuccess();
		} catch (err) {
			console.error('Copy failed', err);
			showError();
		}
	});

	/* ==========================
	   SEND QUOTE VIA EMAIL
	========================== */

	calculator.querySelector('.email-quote')?.addEventListener('click', async () => {
		if (!finalized) {
			await finalizeQuote();
		}

		emailModal?.classList.remove('is-hidden');
	});

	document.addEventListener('click', (e) => {
		const modal = document.getElementById('email-quote-modal');
		if (!modal) return;

		if (!modal.classList.contains('is-hidden') && !modal.contains(e.target) && !e.target.closest('.email-quote')) {
			modal.classList.add('is-hidden');
		}
	});

	calculator.querySelector('.send-email-confirm')?.addEventListener('click', async () => {
		const modal = document.getElementById('email-quote-modal');
		if (!modal) return;

		const sendContent = modal.querySelector('.send-content');
		const sentContent = modal.querySelector('.sent-content');
		const errorEl = modal.querySelector('.form-error');

		const nameInput = modal.querySelector('input[name="name"]');
		const emailInput = modal.querySelector('input[name="email"]');

		const name = nameInput.value.trim();
		const email = emailInput.value.trim();

		errorEl?.classList.add('is-hidden');
		nameInput.classList.remove('is-invalid');
		emailInput.classList.remove('is-invalid');

		let hasError = false;

		if (!name) {
			nameInput.classList.add('is-invalid');
			hasError = true;
		}

		if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
			emailInput.classList.add('is-invalid');
			hasError = true;
		}

		if (hasError) {
			errorEl?.classList.remove('is-hidden');
			return;
		}

		try {
			const res = await fetch(DX_PRICING.ajax_url, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				},
				body: new URLSearchParams({
					action: 'dx_email_quote_pdf',
					name,
					email,
					invoice: document.getElementById('invoice-link')?.value || '',
				}),
			});

			const data = await res.json();

			if (!data.success) {
				throw new Error('Email send failed');
			}

			sendContent.style.display = 'none';
			sentContent.style.display = 'block';
		} catch (err) {
			errorEl?.classList.remove('is-hidden');
			emailInput.classList.add('is-invalid');
		}
	});

	/* ==========================
	   DX MODAL CONTROLLER
	========================== */

	(() => {
		const modal = document.getElementById('email-quote-modal');
		if (!modal) return;

		const openButtons = calculator.querySelectorAll('.email-quote');
		const closeBtn = modal.querySelector('.dx-modal-close');
		const backdrop = modal.querySelector('.dx-modal-backdrop');
		const finishBtn = modal.querySelector('.dx-finish');

		let lastFocusedElement = null;

		const openModal = () => {
			lastFocusedElement = document.activeElement;

			modal.classList.remove('is-hidden');
			requestAnimationFrame(() => {
				modal.classList.add('is-visible');
			});

			document.body.style.overflow = 'hidden';

			const firstInput = modal.querySelector('input');
			firstInput?.focus();
		};

		const closeModal = () => {
			modal.classList.remove('is-visible');

			setTimeout(() => {
				modal.classList.add('is-hidden');
				document.body.style.overflow = '';
				lastFocusedElement?.focus();
			}, 400);
		};

		openButtons.forEach((btn) => {
			btn.addEventListener('click', (e) => {
				e.preventDefault();
				openModal();
			});
		});

		closeBtn?.addEventListener('click', closeModal);
		backdrop?.addEventListener('click', closeModal);
		finishBtn?.addEventListener('click', closeModal);

		document.addEventListener('keydown', (e) => {
			if (e.key === 'Escape' && modal.classList.contains('is-visible')) {
				closeModal();
			}
		});
	})();

	/* ==========================
	   INIT
	========================== */

	successEl?.classList.add('is-hidden');
	bindInputs();
	applyActiveFlow();
	updateSummary();
	syncFeatureExclusivity();
	goToStepIndex(0);
	initScrollableHint();
	syncActiveLabels();
	updateSummaryCopy();

})();