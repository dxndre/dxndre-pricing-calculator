<div class="pricing-calculator" data-step="1">

    <div class="calculator-progress">
		<div class="progress-bar">
			<span class="progress-fill"></span>
		</div>
		<pre class="progress-label headline"></pre>
	</div>

	<div class="calculator-step-container">
		<div class="steps-container">

<div class="calculator-step is-active" data-step="1">
	<h2 class="step-title">1. What service are you looking for?</h2>

	<div class="options-group options-group--services">
		<div class="service-option">
			<label>
				<input type="radio" name="service" value="design">
				<span class="custom-radio"></span>
				Design
			</label>

			<details class="service-option__details">
				<summary>What’s included?</summary>
				<div class="service-option__content">
					<h4>Design</h4>
					<p>Ideal if you need the visual direction before development begins. This can include layout concepts, wireframing, UI direction, design systems, and polished page mockups tailored to your brand and goals.</p>
				</div>
			</details>
		</div>

		<div class="service-option">
			<label>
				<input type="radio" name="service" value="landing_page">
				<span class="custom-radio"></span>
				Landing Page Development
			</label>

			<details class="service-option__details">
				<summary>What’s included?</summary>
				<div class="service-option__content">
					<h4>Landing Page Development</h4>
					<p>Best for campaigns, launches, lead generation, and focused offers. This covers the build of a high-converting single page experience with strong structure, responsive layout, and clear calls to action.</p>
				</div>
			</details>
		</div>

		<div class="service-option">
			<label>
				<input type="radio" name="service" value="development">
				<span class="custom-radio"></span>
				Web Development
			</label>

			<details class="service-option__details">
				<summary>What’s included?</summary>
				<div class="service-option__content">
					<h4>Web Development</h4>
					<p>Suitable for bespoke website builds that may not require WordPress specifically. This focuses on front-end implementation, responsive behaviour, performance, and building out the functionality needed for the project.</p>
				</div>
			</details>
		</div>

		<div class="service-option">
			<label>
				<input type="radio" name="service" value="wp_development">
				<span class="custom-radio"></span>
				WordPress Development
			</label>

			<details class="service-option__details">
				<summary>What’s included?</summary>
				<div class="service-option__content">
					<h4>WordPress Development</h4>
					<p>Perfect for content-managed websites that need flexibility and long-term ease of use. This can include custom themes, bespoke blocks, ACF-powered sections, template builds, and scalable WordPress functionality.</p>
				</div>
			</details>
		</div>

		<div class="service-option">
			<label>
				<input type="radio" name="service" value="comprehensive">
				<span class="custom-radio"></span>
				Comprehensive
			</label>

			<details class="service-option__details">
				<summary>What’s included?</summary>
				<div class="service-option__content">
					<h4>Comprehensive</h4>
					<p>A more end-to-end service that combines strategy, design, development, and refinement. This is ideal if you want one cohesive process from concept through to launch, with less fragmentation across suppliers or stages.</p>
				</div>
			</details>
		</div>

		<div class="service-option">
			<label>
				<input type="radio" name="service" value="retainer">
				<span class="custom-radio"></span>
				Retainer
			</label>

			<details class="service-option__details">
				<summary>What’s included?</summary>
				<div class="service-option__content">
					<h4>Retainer</h4>
					<p>Best for ongoing support rather than a one-off build. This can cover regular updates, design improvements, technical support, WordPress maintenance, feature rollouts, and having reliable development capacity on hand each month.</p>
				</div>
			</details>
		</div>
	</div>

	<div class="calculator-intro-fields">
		<h3 class="calculator-intro-fields__title">Before we continue</h3>
		<p class="calculator-intro-fields__copy">Add your details if you’d like a more personal walkthrough. This is completely optional.</p>

		<div class="calculator-intro-fields__grid">
			<div class="calculator-intro-fields__field">
				<label for="calculator-client-name">Your name <span>(optional)</span></label>
				<input id="calculator-client-name" type="text" name="client_name" placeholder="e.g. D’André">
			</div>

			<div class="calculator-intro-fields__field">
				<label for="calculator-client-company">Company <span>(optional)</span></label>
				<input id="calculator-client-company" type="text" name="client_company" placeholder="e.g. DXNDRE Studio">
			</div>
		</div>
	</div>
</div>

			<div class="calculator-step" data-step="2">
				<h2 class="step-title">2. What best describes the scope?</h2>

				<div class="options-group">
					<label>
						<input type="radio" name="scope" value="small">
						<span class="custom-radio"></span>
						Small (1–3 Pages / Simple Functionality)
					</label>

					<label>
						<input type="radio" name="scope" value="medium">
						<span class="custom-radio"></span>
						Medium (4–8 Pages / Moderate Functionality)
					</label>

					<label>
						<input type="radio" name="scope" value="large">
						<span class="custom-radio"></span>
						Large (9+ Pages / Complex Functionality)
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="3">
				<h2 class="step-title">3. What’s your project type?</h2>

				<div class="options-group long">
					<label>
						<input type="radio" name="type" value="business">
						<span class="custom-radio"></span>
						Business
					</label>

					<label>
						<input type="radio" name="type" value="blog">
						<span class="custom-radio"></span>
						Blog
					</label>

					<label>
						<input type="radio" name="type" value="education">
						<span class="custom-radio"></span>
						Education
					</label>

					<label>
						<input type="radio" name="type" value="forum">
						<span class="custom-radio"></span>
						Forum
					</label>

					<label>
						<input type="radio" name="type" value="personal">
						<span class="custom-radio"></span>
						Personal
					</label>

					<label>
						<input type="radio" name="type" value="entertainment">
						<span class="custom-radio"></span>
						Entertainment
					</label>

					<label>
						<input type="radio" name="type" value="nonprofit">
						<span class="custom-radio"></span>
						Non-Profit Charity
					</label>

					<label>
						<input type="radio" name="type" value="event">
						<span class="custom-radio"></span>
						Event
					</label>

					<label>
						<input type="radio" name="type" value="portfolio">
						<span class="custom-radio"></span>
						Portfolio
					</label>
				</div>
			</div>

            <div class="calculator-step" data-step="4">
				<h2 class="step-title">4. What added functionality do you require?</h2>

				<div class="options-group">
					<label>
						<input type="checkbox" name="features" value="user_account">
						<span class="custom-checkbox"></span>
						User Accounts
					</label>

					<label>
						<input type="checkbox" name="features" value="ecommerce">
						<span class="custom-checkbox"></span>
						eCommerce
					</label>

					<label>
						<input type="checkbox" name="features" value="integration">
						<span class="custom-checkbox"></span>
						External Integrations
					</label>

                    <label>
						<input type="checkbox" name="features" value="none">
						<span class="custom-checkbox"></span>
						No added functionality
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="5">
				<h2 class="step-title">5. What’s your ideal timeline?</h2>

				<div class="options-group">
					<label>
						<input type="radio" name="timeline" value="no_rush">
						<span class="custom-radio"></span>
						No Rush (12+ Weeks Turnaround)
					</label>

					<label>
						<input type="radio" name="timeline" value="flexible">
						<span class="custom-radio"></span>
						Standard (6-12 Weeks Turnaround)
					</label>

					<label>
						<input type="radio" name="timeline" value="priority">
						<span class="custom-radio"></span>
						Priority (1-4 Weeks Turnaround)
					</label>

					<label>
						<input type="radio" name="timeline" value="urgent">
						<span class="custom-radio"></span>
						Urgent (Within 1 Week Turnaround)
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="6">
				<h2 class="step-title">6. Do you need ongoing support?</h2>

				<div class="options-group">
					<label>
						<input type="checkbox" name="extras" value="maintenance">
						<span class="custom-checkbox"></span>
						Ongoing Maintenance & Updates
					</label>

					<label>
						<input type="checkbox" name="extras" value="seo">
						<span class="custom-checkbox"></span>
						Basic SEO setup & Optimisation
					</label>

					<label>
						<input type="checkbox" name="extras" value="hosting">
						<span class="custom-checkbox"></span>
						Hosting & Monitoring
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="retainer_level">
				<h2 class="step-title">2. What level of monthly support do you need?</h2>

				<div class="options-group">
					<label>
						<input type="radio" name="retainer_level" value="essentials">
						<span class="custom-radio"></span>
						Essentials
					</label>

					<label>
						<input type="radio" name="retainer_level" value="growth">
						<span class="custom-radio"></span>
						Growth
					</label>

					<label>
						<input type="radio" name="retainer_level" value="partner">
						<span class="custom-radio"></span>
						Partner
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="retainer_areas">
				<h2 class="step-title">3. What would you like ongoing support with?</h2>

				<div class="options-group long">
					<label>
						<input type="checkbox" name="retainer_areas" value="design">
						<span class="custom-checkbox"></span>
						Design
					</label>

					<label>
						<input type="checkbox" name="retainer_areas" value="landing_pages">
						<span class="custom-checkbox"></span>
						Landing Pages
					</label>

					<label>
						<input type="checkbox" name="retainer_areas" value="wordpress">
						<span class="custom-checkbox"></span>
						WordPress Development
					</label>

					<label>
						<input type="checkbox" name="retainer_areas" value="performance">
						<span class="custom-checkbox"></span>
						Performance Optimisation
					</label>

					<label>
						<input type="checkbox" name="retainer_areas" value="seo">
						<span class="custom-checkbox"></span>
						SEO Implementation
					</label>

					<label>
						<input type="checkbox" name="retainer_areas" value="content_updates">
						<span class="custom-checkbox"></span>
						Content Updates
					</label>

					<label>
						<input type="checkbox" name="retainer_areas" value="analytics">
						<span class="custom-checkbox"></span>
						Analytics & Tracking
					</label>

					<label>
						<input type="checkbox" name="retainer_areas" value="technical_support">
						<span class="custom-checkbox"></span>
						Technical Support
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="retainer_turnaround">
				<h2 class="step-title">4. What turnaround speed do you need?</h2>

				<div class="options-group">
					<label>
						<input type="radio" name="retainer_turnaround" value="standard">
						<span class="custom-radio"></span>
						Standard
					</label>

					<label>
						<input type="radio" name="retainer_turnaround" value="priority">
						<span class="custom-radio"></span>
						Priority
					</label>

					<label>
						<input type="radio" name="retainer_turnaround" value="fast_track">
						<span class="custom-radio"></span>
						Fast-track
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="retainer_commitment">
				<h2 class="step-title">5. What commitment are you comfortable with?</h2>

				<div class="options-group">
					<label>
						<input type="radio" name="retainer_commitment" value="monthly">
						<span class="custom-radio"></span>
						Monthly rolling
					</label>

					<label>
						<input type="radio" name="retainer_commitment" value="3_months">
						<span class="custom-radio"></span>
						3 Months
					</label>

					<label>
						<input type="radio" name="retainer_commitment" value="6_months">
						<span class="custom-radio"></span>
						6 Months
					</label>

					<label>
						<input type="radio" name="retainer_commitment" value="12_months">
						<span class="custom-radio"></span>
						12 Months
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="retainer_addons">
				<h2 class="step-title">6. Would you like any additional monthly add-ons?</h2>

				<div class="options-group">
					<label>
						<input type="checkbox" name="retainer_addons" value="strategy_call">
						<span class="custom-checkbox"></span>
						Extra Strategy Call
					</label>

					<label>
						<input type="checkbox" name="retainer_addons" value="additional_landing_page">
						<span class="custom-checkbox"></span>
						Additional Landing Page Capacity
					</label>

					<label>
						<input type="checkbox" name="retainer_addons" value="reporting_dashboard">
						<span class="custom-checkbox"></span>
						Reporting Dashboard
					</label>

					<label>
						<input type="checkbox" name="retainer_addons" value="emergency_support">
						<span class="custom-checkbox"></span>
						Emergency Support
					</label>
				</div>
			</div>

			<div class="calculator-step" data-step="7">
				<h2 class="step-title" data-summary-title>Your project outline is ready.</h2>

				<p class="step-intro" data-summary-intro>
					This estimate reflects the scope, priorities, and level of craftsmanship you’ve selected.
					It’s a considered starting point - with no obligation and no pressure to proceed.
				</p>

				<div class="invoice-summary is-hidden" id="invoice-summary">
					<label for="invoice-link">Your invoice reference</label>
					<p>Keep this handy so you can access your quote anywhere, anytime.</p>

					<div class="copy-field">
						<input
							id="invoice-link"
							type="text"
							value=""
							readonly
						>

						<button
							type="button"
							class="btn btn-outline copy-invoice"
							aria-label="Copy link"
							aria-live="polite"
						>
							<i class="fa-solid fa-copy"></i>
						</button>

						<a
							href="#"
							target="_blank"
							rel="noopener"
							class="btn btn-outline view-invoice is-disabled"
							id="view-invoice"
						>
							View
							<i class="fa-solid fa-file-invoice"></i>
						</a>
					</div>
				</div>

				<!-- Email Modal -->
				<div class="dx-modal email-quote-modal is-hidden" id="email-quote-modal">
					<div class="dx-modal-backdrop"></div>

					<div class="dx-modal-panel" role="dialog" aria-modal="true">
						<button type="button" class="dx-modal-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>

						<div class="content-side">
							<div class="send-content">
								<h3>Email your proposal</h3>
								<p>Enter your details and I’ll send your PDF to your inbox.</p>

								<span class="form-error is-hidden" role="alert">
									<i class="fa-solid fa-circle-exclamation"></i> Please double-check the form and try again.
								</span>

								<input type="text" name="name" placeholder="Your Name" required>
								<input type="email" name="email" placeholder="Your Email" required>

								<button type="button" class="btn send-email-confirm">
									Send Proposal <i class="fa-solid fa-paper-plane"></i>
								</button>
							</div>
							<div class="sent-content">
								<h3>Proposal Sent</h3>
								<p>Brilliant - your proposal has been sent! Please check your inbox.</p>

								<button type="button" class="btn dx-finish">
									Finish <i class="fa-solid fa-check"></i>
								</button>
							</div>
						</div>
						<div class="graphic-side">
							<img src="<?php echo esc_url( plugin_dir_url( dirname( __FILE__ ) ) . 'assets/img/206-crop.png' ); ?>" alt="206 Bus">
						</div>
						
					</div>
				</div>

				<h4>What would you like to do next?</h4>

				<div class="summary-actions">			
					<button class="btn download-pdf">
						Download proposal (PDF)
						<i class="fa-solid fa-file-pdf"></i>
					</button>

					<button class="btn email-quote">
						Email me a copy
						<i class="fa-solid fa-envelope"></i>
					</button>

					<a
						href="https://calendly.com/dxndre/30min?source=pricing-calculator"
						class="btn btn-outline js-calendly-popup"
						target="_blank"
						rel="noopener noreferrer"
					>
						Discuss this project
						<span class="meta">
							30-minute call · No obligation
						</span>
					</a>

					<p class="summary-note">
						💡 You’ll speak directly with me — no sales process, no intermediaries.
						Feel free to download or reference this proposal during our conversation.
					</p>
				</div>
			</div>
		</div>

		<div class="calculator-summary">
			<div class="summary-content">
				<ul class="summary-breakdown"></ul>
				<div class="summary-price">
					<p>Your projected investment</p>
					<span class="price">£0</span>
				</div>
			</div>
		</div>
	</div>


    <div class="calculator-success is-hidden">
        <h2>Thank you 🎉</h2>
        <p>Your quote has been sent successfully. I’ll be in touch shortly.</p>
    </div>

	<div class="calculator-nav">
		<button class="prev-step" disabled>Back</button>
		<button class="next-step" disabled>Next</button>
	</div>
</div>